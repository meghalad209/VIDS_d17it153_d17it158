using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using TrueVision3D;
using DxVBLibA;


namespace TrueVisionTest
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }


        private void button1_Click(object sender, EventArgs e)
        {
            Main_Quit();
            Application.Exit();
        }

        TVMesh  _meshRoom = null;
        TVMesh _meshTable = null;
        TVMesh _meshChair = null;
        TVMesh _meshChair2 = null;
        TVMesh _die1 = null;
        TVMesh _die2 = null;
        TVMesh _sunglasses = null;
        TVMesh _sphere = null;
        TVMesh _meshTank = null;
        TVEngine TV = null;
        TVScene _scene = null;
        TVGlobals global = new TVGlobals();
        TVLightEngine _TVLightEngine = null;
        TVInputEngine InputEngine = new TVInputEngine();
        TVTextureFactoryClass TexFactory = new TVTextureFactoryClass();
        TVMaterialFactory MatFactory = new TVMaterialFactory();
        TVLandscape Land;


        // positions
        //Movements for the objects
        float x_move = 30.0f, y_move = -30.0f, z_move = 150.0f;

        void InitializeTrueVision()
        {
            // create a new game engine
            TV = new TVEngine();

            // set the engine to point the picture box so all rendering will
            // occur inside the picture box in the form
            TV.Init3DWindowedMode(this.pictureBox1.Handle.ToInt32(), true);

            //This is the  path where our media (texture and meshes) files are placed
            TV.SetSearchDirectory(System.Windows.Forms.Application.ExecutablePath);

            // set the rotation angle to be in degrees
            TV.SetAngleSystem(CONST_TV_ANGLE.TV_ANGLE_DEGREE);

            // We want to see the Frames Per second
            TV.DisplayFPS = true;
        }

        DxVBLibA.D3DLIGHT8 light;

        /// <summary>
        /// Set up the lighting for the scene
        /// </summary>
        void SetupLighting()
        {
            _TVLightEngine = new TVLightEngine();
            //Initializing the light with values
            light.Type = DxVBLibA.CONST_D3DLIGHTTYPE.D3DLIGHT_POINT;
            light.ambient.a = 0.8f;
            light.ambient.r = 0.8f;
            light.ambient.g = 0.8f;
            light.ambient.b = 0.8f;
            light.diffuse.a = 1.0f;
            light.diffuse.r = 1.0f;
            light.diffuse.g = 1.0f;
            light.diffuse.b = 1.0f;
            light.specular.a = 1f;
            light.specular.r = 0.2f;
            light.specular.g = 0.2f;
            light.specular.b = 0.2f;
            light.Direction = global.Vector3(0.0f, 1.0f, 0.0f);
            light.Position = global.Vector3(0.0f, 400.0f, 10.0f);
            light.Range = 1000.0f;
            light.Attenuation0 = 0.5f;
            light.Falloff = 1;
            light.Phi = ((float)Math.PI) / 4.0f;
            light.Theta = light.Phi / 2;
            //Create the light in the scene
            _TVLightEngine.CreateLight(ref light, "light", false);
            _scene.SetSpecularLightning(true);
        }

        private float _rotationvalue = 5;

        private void Form1_Load(object sender, EventArgs e)
        {
            // set up the initial scene
            SetupTheInitialScene();

             // show the form and give it focus
             this.Show();
             this.Focus();

            // start up the main loop, setting the loop guard to ON
             DoLoop = true;
             Main_Loop();
        }

        private void SetupTheInitialScene()
        {
            // initialize true vision details
            InitializeTrueVision();

            // create a new scene
            _scene = new TVScene();

            // set the scene background color
            _scene.SetSceneBackGround(0f, 0.3f, 0.9f);

            // set the lighting of the scene
            SetupLighting();


            // Load Textures
            LoadTextures();

            // create wall
            CreateWalls();


            //Set the position  of the room mesh
            _meshRoom.SetPosition(x_move, y_move, z_move);

            // create different shapes in the room
            CreateMeshShapes();
        }

        private void CreateMeshShapes()
        {
           // create a table with a transparent tabletop
            CreateMeshTable();

            // create a chair
            CreateChair1();

            // create another chair
            CreateChair2();

            // create dice
            CreateDie1();

            CreateDie2();


            // create sunglasses and place them on the table by adjusting the position
            CreateSunglasses();

            // create a sphere inside the sunglasses
            CreateSphere();
        }

        private void CreateSphere()
        {
            _sphere = (TVMeshClass)_scene.CreateMeshBuilder("sphere");
            _sphere.LoadXFile(@"meshes\sphere.x", true, true);
            _sphere.SetPosition(80f, -40.0f, 310.0f);
            _sphere.RotateY(25, true);
            _sphere.ScaleMesh(15, 15, 15);
            _sphere.SetTexture(global.GetTex("sandstone"), -1);
        }

        private void CreateSunglasses()
        {
            _sunglasses = (TVMeshClass)_scene.CreateMeshBuilder("sunglasses");
            _sunglasses.LoadXFile(@"meshes\sunglass.x", true, true);

            // place glasses in the same place as the table, and it will appear
            // as if they are resting on top of the table
            _sunglasses.SetPosition(80f, 100.0f, 310.0f);
            _sunglasses.RotateY(25, true);
            _sunglasses.ScaleMesh(15, 15, 15);
        }

        private void CreateDie2()
        {
            _die2 = (TVMeshClass)_scene.CreateMeshBuilder("die2");
            _die2.LoadXFile(@"meshes\die.x", true, true);
            _die2.SetPosition(-200.0f, -40.0f, 340.0f);
            _die2.ScaleMesh(10, 10, 10);

            // rotate the dice slightly
            _die2.RotateX(35.0f, true);
            _die2.SetTexture(global.GetTex("marble"), -1);
        }

        private void CreateDie1()
        {
            _die1 = (TVMeshClass)_scene.CreateMeshBuilder("die1");
            _die1.LoadXFile(@"meshes\die.x", true, true);
            _die1.SetPosition(-200.0f, -40.0f, 280.0f);
            _die1.ScaleMesh(10, 10, 10);
            _die1.SetTexture(global.GetTex("marble"), -1);
        }

        private void CreateChair2()
        {
            _meshChair2 = (TVMeshClass)_scene.CreateMeshBuilder("chair2");
            _meshChair2.LoadXFile(@"meshes\chair.x", true, true);
            _meshChair2.SetPosition(-200.0f, -80.0f, 340.0f);
            _meshChair2.ScaleMesh(2, 2, 2);
            _meshChair2.SetTexture(global.GetTex("wood"), -1);
        }

        private void CreateChair1()
        {
            _meshChair = (TVMeshClass)_scene.CreateMeshBuilder("chair");
            _meshChair.LoadXFile(@"meshes\chair.x", true, true);
            _meshChair.SetPosition(-300.0f, -80.0f, 340.0f);
            _meshChair.ScaleMesh(2, 2, 2);
            _meshChair.SetTexture(global.GetTex("wood"), -1);
        }

        private void CreateMeshTable()
        {
            // create a mesh object called table
            _meshTable = (TVMeshClass)_scene.CreateMeshBuilder("table");

            // load the object from an x file
            _meshTable.LoadXFile(@"meshes\glasstable.x", true, true);

            // set its position
            _meshTable.SetPosition(80.0f, -50.0f, 340.0f);

            // make the table 3x larger
            _meshTable.ScaleMesh(3, 3, 3);

            // rotate it 25 degrees around the Y 3D Axis
            _meshTable.RotateY(25, true);

            // set the tables texture to sandstone
            _meshTable.SetTexture(global.GetTex("sandstone"), -1);
        }


        private void CreateWalls()
        {
            _meshRoom = (TVMeshClass)_scene.CreateMeshBuilder("room");
            _meshRoom.AddWall3D(global.GetTex("cinder"), 350.0f, -350.0f, -350.0f, -350.0f, 350.0f, 5.0f, true, false, -50.0f, 5.0f, 5.0f);
            _meshRoom.AddWall3D(global.GetTex("cinder"), -350.0f, -350.0f, -350.0f, 350.0f, 350.0f, 5.0f, true, false, -50.0f, 5.0f, 5.0f);
            _meshRoom.AddWall3D(global.GetTex("cinder"), -350.0f, 350.0f, 350.0f, 350.0f, 350.0f, 5.0f, true, false, -50.0f, 5.0f, 5.0f);
            _meshRoom.AddWall3D(global.GetTex("cinder"), 350.0f, 350.0f, 350.0f, -350.0f, 350.0f, 5.0f, true, false, -50.0f, 5.0f, 5.0f);
            _meshRoom.AddFloor(global.GetTex("sandstone"), -350.0f, -350 - 0f, 350.0f, 350.0f, -50.0f, 10.0f, 10.0f, true, false);
        }

        private void LoadTextures()
        {
            int textureID1 = _scene.LoadTexture("textures\\marble.jpg", -1, -1, "marble");
            int textureID2 = _scene.LoadTexture("textures\\cinder.bmp", -1, -1, "cinder");
            int textureID3 = _scene.LoadTexture("textures\\granite.bmp", -1, -1, "granite");
            int textureID4 = _scene.LoadTexture("textures\\metal.bmp", -1, -1, "metal");
            int textureID5 = _scene.LoadTexture("textures\\sandstone.bmp", -1, -1, "sandstone");
            int textureID6 = _scene.LoadTexture("textures\\oldrock.bmp", -1, -1, "oldrock");
        }

        bool DoLoop = false;

        private void Main_Quit()
        {
            DoLoop = false;
        }

        void RotateSomeObjects()
        {
            // rotate first die around the X Axis if die flag is set
            if (_rotateDie)
            {
                _die1.RotateX(5, true);

                // rotate second die around the X Axis and Z Axis
                _die2.RotateX(5, true);
                _die2.RotateZ(5, true);
            }

            // rotate the sunglasses around the Y Axis if sunglasses flag is set
            if (_rotateGlasses)
            {
                _sunglasses.RotateY(5, true);
            }
        }

        private void Main_Loop()
        {
            int fps;



            // We loop all of this until the DoLoop isn't True.
            while (DoLoop == true)
            {
                System.Windows.Forms.Application.DoEvents();

           // for games, we would add input and movement checks here
               CheckInput();
         //       CheckMovement();

                //Get the Frame per Second
                fps = (int)TV.GetFPS();

                // rendering is started by clearing the image
                TV.Clear(false);

                // rotate some of the objects set up in the form load
                RotateSomeObjects(); 

                _scene.RenderAllMeshes(true);

                // Then, we display everything that we have rendered (from the
                // objects of the world) to the screen.
                TV.RenderToScreen();

            }

            // We ask to quit.
            Main_Quit();
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            DoLoop = false;
        }
        private bool _rotateDie = true;
        private bool _rotateGlasses = true;

        private void CheckInput()
        {
            // check if we want to stop the sunglasses
        	if (InputEngine.IsKeyPressed(CONST_TV_KEY.TV_KEY_S))             
		    	_rotateGlasses = false;  // stop the glasses
        
            // check if we want to stop the die
    		if (InputEngine.IsKeyPressed(CONST_TV_KEY.TV_KEY_D))
                _rotateDie = false; // stop the die

            if (InputEngine.IsKeyPressed(CONST_TV_KEY.TV_KEY_R))
            {
                // restart both glasses and die
                _rotateGlasses = true;
                _rotateDie = true;
            }

        }

    }
}