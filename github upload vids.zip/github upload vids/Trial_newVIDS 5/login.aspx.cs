﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btn_login_Click(object sender, EventArgs e)
    {
        int ch = Convert.ToInt32(rbl_type.SelectedValue);

        if (ch == 0)
        {
            SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\VIDS.mdf;Integrated Security=True");
            con.Open();
            SqlCommand cmd = new SqlCommand("select COUNT(*)FROM employee WHERE email='" + txtid.Text + "' and pswd='" + txtpswd.Text + "'");
            cmd.Connection = con;
            int OBJ = Convert.ToInt32(cmd.ExecuteScalar());
            if (OBJ > 0)
            {
                Response.Redirect("admin.aspx");
            }
            else
            {
                Label1.Text = "Invalid username or password";
                // this.Label1.ForeColor = Color.Red;
            }
            Session["id"] = "admin";
            Response.Redirect("admin.aspx");
        }
        else 
        {
            SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\VIDS.mdf;Integrated Security=True");
            con.Open();
            SqlCommand cmd = new SqlCommand("select COUNT(*)FROM register WHERE email='" + txtid.Text + "' and pswd='" + txtpswd.Text + "'");
            cmd.Connection = con;
            int OBJ = Convert.ToInt32(cmd.ExecuteScalar());
            if (OBJ > 0)
            {
                Response.Redirect("design.aspx");
            }
            else
            {
                Label1.Text = "Invalid username or password";
                // this.Label1.ForeColor = Color.Red;
            }
            Session["id"] = "customer";
            Response.Redirect("design.aspx");

        }
        //else
        //{
        //    SqlConnection con = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=|DataDirectory|\VIDS.mdf;Integrated Security=True;User Instance=True");
        //    con.Open();
        //    SqlCommand cmd = new SqlCommand("select COUNT(*)FROM emp_reg WHERE email_id='" + txtid.Text + "' and pswd='" + txtpswd.Text + "'");
        //    cmd.Connection = con;
        //    int OBJ = Convert.ToInt32(cmd.ExecuteScalar());
        //    if (OBJ > 0)
        //    {
        //        Response.Redirect("emp_home.aspx");
        //    }
        //    else
        //    {
        //        Label1.Text = "Invalid username or password";
        //        // this.Label1.ForeColor = Color.Red;
        //    }
        //    Session["id"] = "employee";
        //    Response.Redirect("emp_home.aspx");
        //    //int ch = Convert.ToInt32(rbl.SelectedValue);

        //    //if (ch == 0)
        //    //{
        //    //    Session["id"] = "admin";
        //    //    Response.Redirect("admin.aspx");
        //    //}
        //    //else if (ch == 1)
        //    //{
        //    //    Session["id"] = "customer";
        //    //    Response.Redirect("customer.aspx");
        //    //}
        //    //else
        //    //{
        //    //    Session["id"] = "employee";
        //    //    Response.Redirect("employee.aspx");
        //    //}

    }
}
