﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Net;
using System.Net.Mail;
using System.Configuration;
using System.Data.SqlClient;

public partial class register : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btnsubmit_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\VIDS.mdf;Integrated Security=True");
        con.Open();
        String str = "insert into register values('" + txtfname.Text + "','" + txtlname.Text + "','" + RadioButtongender.SelectedValue + "','" + txtdob.Text + "','" + txtemailid.Text + "','" + txtpswd.Text + "','" + txtadd.Text + "','" + txtcity.Text + "','" + txtstate.Text + "','" + txtpc.Text + "','" + txtphn.Text + "','" + txthque.Text + "','" + txthans.Text + "')";
        SqlCommand cmd = new SqlCommand(str, con);
        cmd.ExecuteNonQuery();

        con.Close();
        Response.Write("registration completed");

        using (MailMessage mm = new MailMessage(ConfigurationManager.AppSettings["SMTPuser"], txtemailid.Text))
        {
            mm.Subject = "VIDStudio confirmation";
            mm.Body = "Congratualiations, Your registration is sucessfully done! Thank you";
            SmtpClient smtp = new SmtpClient();
            smtp.Host = ConfigurationManager.AppSettings["Host"];
            smtp.EnableSsl = Convert.ToBoolean(ConfigurationManager.AppSettings["EnableSSL"]);
            NetworkCredential NetworkCred = new NetworkCredential(ConfigurationManager.AppSettings["SMTPuser"],
                ConfigurationManager.AppSettings["SMTPpassword"]);

            smtp.UseDefaultCredentials = true;
            smtp.Credentials = NetworkCred;
            smtp.Port = int.Parse(ConfigurationManager.AppSettings["Port"]);
            smtp.Send(mm);
        }

        txtfname.Text = "";
        txtlname.Text = "";
        txtdob.Text = "";
        txtemailid.Text = "";
        txtpswd.Text = "";
        txtadd.Text = "";
        txtcity.Text = "";
        txtstate.Text = "";
        txtpc.Text = "";
        txtphn.Text = "";
        txthque.Text = "";
        txthans.Text = "";
        Response.Redirect("login.aspx");
    }
}